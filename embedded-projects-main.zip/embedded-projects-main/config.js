/*
 * @Author: Lin 3194563857@qq.com
 * @Date: 2026-06-08 22:40:44
 * @LastEditors: Lin 3194563857@qq.com
 * @LastEditTime: 2026-06-08 22:48:23
 * @FilePath: \项目介绍\config.js
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
// ============================================================
//  配置文件 — 修改这里的内容即可更新网站
//  视频文件请放入 videos/ 文件夹，然后在这里填写文件名
// ============================================================

const SITE_CONFIG = {
  // -- 个人信息 --
  avatar: "avatar.jpg",
  name: "林楚淮",
  title: "嵌入式软件开发工程师",
  bio: "惠州学院电子信息工程本科，具备从方案设计到代码落地的独立开发能力",
  contact: {
    email: "3194563857@qq.com",
  },

  // -- 技能标签 --
  skills: [
    "STM32（标准库/HAL库）",
    "ESP32（ESP-IDF）",
    "FreeRTOS",
    "IIC / SPI / UART",
    "蓝牙 / WiFi / 2.4G",
    "PID / 串级PID",
    "卡尔曼滤波 / 四元数解算",
    "Altium Designer",
    "Keil / VSCode",
  ],

  // -- 项目列表 --
  // 每个项目包含: name(项目名), description(简短描述), video(视频路径), tags(技术标签), detail(详细介绍)
  projects: [
    {
      name: "基于 ESP32 + FreeRTOS 的低功耗智能门锁",
      description:
        "以 ESP32-C3 为主控，实现指纹、触摸密码、手机蓝牙三种解锁方式，支持 AB 分区 OTA 升级与低功耗管理",
      video: "videos/smart-lock.mp4",
      tags: ["ESP32", "FreeRTOS", "UART", "IIC", "蓝牙+WiFi", "OTA"],
      detail:
        "设计并实现低功耗智能门锁系统，以 ESP32-C3 为主控，FreeRTOS 进行多任务调度。\n\n集成 FPM383 光学指纹模块与 SC12B12 电容触摸感应芯片，配合 ESP32 内置蓝牙，实现指纹、触摸密码、手机蓝牙三种解锁方式。\n\n基于 ESP32 官方 API 实现 AB 分区 OTA 固件升级，升级失败自动回滚至备用分区，确保远程更新不中断服务。\n\n设计电源管理与深度休眠策略，有效降低待机功耗，满足住宅场景长期电池供电需求。\n\n项目时间：2025.11 - 2026.01",
    },
    {
      name: "基于 STM32 + FreeRTOS 的四轴飞行器飞控系统",
      description:
        "从零搭建飞控与遥控系统，涵盖传感器融合、串级 PID 姿态控制、2.4G 无线通信及遥控交互",
      video: "videos/drone.mp4",
      tags: ["STM32", "FreeRTOS", "MPU6050", "串级PID", "2.4G", "PWM"],
      detail:
        "从零搭建四轴飞行器飞控与遥控系统，涵盖传感器融合、姿态控制、无线通信及遥控交互。飞控板通过 MPU6050 采集六轴运动数据，经一阶低通滤波 → 卡尔曼滤波 → 四元数解算，实时获取欧拉角姿态信息。\n\n采用串级 PID 控制架构（外环角度环 + 内环角速度环），PWM 直驱 8520 空心杯电机，实现飞行器稳定悬停与灵活姿态响应。遥控板集成双摇杆 ADC 采样与按键微调，OLED 实时显示校准参数，通过 SI24R1 2.4G 模块与飞控板双向通信。\n\n实现失联自动降落、LED 状态指示等安全功能。\n\n项目时间：2026.01 - 2026.03",
    },
    {
      name: "基于 STM32 的步进电机控制系统",
      description:
        "基于 FreeRTOS 多任务管理，自研 PID 与梯形加减速双算法，支持 Flash 断电存储与 OLED 实时显示",
      video: "videos/stepper-motor.mp4",
      tags: ["STM32", "FreeRTOS", "PID", "梯形加减速", "Flash存储", "OLED"],
      detail:
        "基于 FreeRTOS 进行多任务管理，将电机控制、参数存储、显示刷新等任务解耦，通过队列与信号量实现任务间通信。\n\n从零驱动步进电机，通过定时器产生精确步进脉冲，控制 GPIO 输出方向信号，实现正反转与任意圈数调节，不依赖现成电机驱动库。\n\n自研 PID 与梯形加减速两种控制算法，根据负载与转速需求灵活切换，保证电机启停平稳、不失步。使用 Flash 存储运行参数（圈数、方向、算法模式），断电后自动恢复，无需重复配置。OLED 屏实时显示运行状态与当前算法模式。\n\n正在扩展多协议通信（Modbus/RS485、CAN、LoRa、MQTT），支持通过网关远程控制，适配工业与 IoT 场景。\n\n项目时间：2026.03 - 至今（开发中）",
    },
  ],
};
